
INTERNET EXPLORER:

If you get an Internet Explorer security warning on opening StatPlanet.html, use
StatPlanet_IE_offline.html instead. The security warning should disappear in Internet Explorer
once it is online.
